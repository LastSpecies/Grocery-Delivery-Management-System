package com.edu.dao;

import java.sql.Date;           
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer customerid;
	@Column(length=15,nullable=false)
	private String customerfirstname;
	@Column(length=15,nullable=false)
	private String customerlastname;
	@Column(nullable=false)
	@Size(min=6,max=14,message="Passsword length must be 6 and 14 characters")
	@Pattern(
	        regexp = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).+$",
	        message = "Password must have at least one capital letter, one number, and one special character."
	    )
	private String customerpassword;
	@Column(nullable=false,unique=true)
	@Pattern(regexp="[0-9]{10}", message="Phone number must be 10 digits")
	private String customerphoneno;
	private Date customerdob;
     @Column(unique = true, nullable = false)
     @Email(regexp = ".+@.+\\..+", message = "Invalid email address")
     @Pattern(regexp = "^[A-Za-z0-9+_.-]+@(.+)$", message = "Invalid email address")
	private String customeremailid;
     
     @OneToOne(mappedBy = "customer") 
	    private Cart cart;
	 
	 @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
	    private List<OrderMain> orders;
	 
	 
	public Cart getCart() {
		return cart;
	}


	public void setCart(Cart cart) {
		this.cart = cart;
	}


	public List<OrderMain> getOrders() {
		return orders;
	}


	public void setOrders(List<OrderMain> orders) {
		this.orders = orders;
	}


	public Customer() {
	  super();
		// TODO Auto-generated constructor stub
	}


	public Customer(String customerfirstname, String customerlastname, String customerpassword, String customerphoneno,
			Date customerdob, String customeremailid) {
		super();
		this.customerfirstname = customerfirstname;
		this.customerlastname = customerlastname;
		this.customerpassword = customerpassword;
		this.customerphoneno = customerphoneno;
		this.customerdob = customerdob;
		this.customeremailid = customeremailid;
	}
	

	public String getCustomeremailid() {
		return customeremailid;
	}


	public void setCustomeremailid(String customeremailid) {
		this.customeremailid = customeremailid;
	}


	public Integer getCustomerid() {
		return customerid;
	}

	public void setCustomerid(Integer customerid) {
		this.customerid = customerid;
	}

	public String getCustomerfirstname() {
		return customerfirstname;
	}

	public void setCustomerfirstname(String customerfirstname) {
		this.customerfirstname = customerfirstname;
	}

	public String getCustomerlastname() {
		return customerlastname;
	}

	public void setCustomerlastname(String customerlastname) {
		this.customerlastname = customerlastname;
	}

	public String getCustomerpassword() {
		return customerpassword;
	}

	public void setCustomerpassword(String customerpassword) {
		this.customerpassword = customerpassword;
	}

	public String getCustomerphoneno() {
		return customerphoneno;
	}

	public void setCustomerphoneno(String customerphoneno) {
		this.customerphoneno = customerphoneno;
	}

	public Date getCustomerdob() {
		return customerdob;
	}

	public void setCustomerdob(Date customerdob) {
		this.customerdob = customerdob;
	}

	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", customerfirstname=" + customerfirstname + ", customerlastname="
				+ customerlastname + ", customerpassword=" + customerpassword + ", customerphoneno=" + customerphoneno
				+ ", customerdob=" + customerdob + ", customeremailid=" + customeremailid + "]";
	}
	

}
