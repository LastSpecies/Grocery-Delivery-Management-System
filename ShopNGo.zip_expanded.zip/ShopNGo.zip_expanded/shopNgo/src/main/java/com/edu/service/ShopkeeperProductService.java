package com.edu.service;

import java.util.List;

import com.edu.dao.ShopkeeperProduct;

public interface ShopkeeperProductService {

	ShopkeeperProduct saveProduct(ShopkeeperProduct shopkeeperproduct);

	List<ShopkeeperProduct> getAllProducts();

	void updateProductByName(String shopkeeperproductname, Long shopkeeperproductquantity,
			Integer shopkeeperproductprice);

	void deleteProductByName(String shopkeeperproductname);
	
	ShopkeeperProduct addProductImage(ShopkeeperProduct product);

	ShopkeeperProduct getProductDetailsById(Integer shopkeeperproductid);

	void deleteProductById(Integer shopkeeperproductid);
}
