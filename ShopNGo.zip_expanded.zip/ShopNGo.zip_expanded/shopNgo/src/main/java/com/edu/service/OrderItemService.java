package com.edu.service;

import com.edu.dao.OrderItem;

public interface OrderItemService {

	OrderItem createOrderItem(OrderItem orderItem);

	OrderItem orderitemAssignOrderMain(Integer itemid, Integer orderid);

	OrderItem orderitemAssignProduct(Integer itemid, Integer shopkeeperproductid);

}
