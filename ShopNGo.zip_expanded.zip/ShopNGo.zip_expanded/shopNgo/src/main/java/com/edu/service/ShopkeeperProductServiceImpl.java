package com.edu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.dao.ShopkeeperProduct;
import com.edu.repository.ShopkeeperProductRepository;


@Service
public class ShopkeeperProductServiceImpl implements ShopkeeperProductService {
	
	@Autowired
	private ShopkeeperProductRepository shopkeeperProductRepository;

	@Override
	public ShopkeeperProduct saveProduct(ShopkeeperProduct shopkeeperproduct) {
		// TODO Auto-generated method stub
		return shopkeeperProductRepository.save(shopkeeperproduct);
	}

	@Override
	public List<ShopkeeperProduct> getAllProducts() {
		// TODO Auto-generated method stub
		return shopkeeperProductRepository.findAll();
	}

	@Override
	public void updateProductByName(String shopkeeperproductname, Long shopkeeperproductquantity,
			Integer shopkeeperproductprice) {
		shopkeeperProductRepository.updateProductByName(shopkeeperproductname,shopkeeperproductquantity,shopkeeperproductprice);
		
	}

	@Override
	public void deleteProductByName(String shopkeeperproductname) {
		
		shopkeeperProductRepository.deleteProductByName(shopkeeperproductname);
		
	}

	@Override
	public ShopkeeperProduct addProductImage(ShopkeeperProduct shopkeeperProduct) {
		// TODO Auto-generated method stub
				return shopkeeperProductRepository.save(shopkeeperProduct);
	}

	@Override
	public ShopkeeperProduct getProductDetailsById(Integer shopkeeperproductid) {
		// TODO Auto-generated method stub
		return shopkeeperProductRepository.findById(shopkeeperproductid).get();
	}

	@Override
	public void deleteProductById(Integer shopkeeperproductid) {
		// TODO Auto-generated method stub
		shopkeeperProductRepository.deleteById(shopkeeperproductid);
	}

}
