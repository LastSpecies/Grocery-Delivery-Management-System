package com.edu.controller;

import java.util.Date;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.dao.OrderItem;
import com.edu.dao.OrderMain;
import com.edu.repository.OrderMainRepository;
import com.edu.service.OrderMainService;

@RestController
public class OrderMainController {
	
	@Autowired
	private OrderMainService orderMainService;
	
	@Autowired
	private OrderMainRepository orderMainRepository;

	
	 @PostMapping("/saveorder_main")
	    public ResponseEntity<OrderMain> createOrder(@RequestBody OrderMain order) {
	        OrderMain createdOrder = orderMainService.createOrder(order);
	        return new ResponseEntity<>(createdOrder, HttpStatus.CREATED);
	    }
	 
	@GetMapping("/order/{orderid}")
	   public ResponseEntity<OrderMain> getOrderById(@PathVariable Integer orderid) {
	      OrderMain order = orderMainService.getOrderById(orderid);
	        if (order == null) {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	        return new ResponseEntity<>(order, HttpStatus.OK);
	   }
	 @GetMapping("/AllOrders")
	   public ResponseEntity<List<OrderMain>> getAllOrders() {
	        List<OrderMain> orders = orderMainService.getAllOrders();
	        return new ResponseEntity<>(orders, HttpStatus.OK);
	    }
	 @PutMapping("/OrderassigndCustomer/{orderid}/Product/{customerid}")
		public OrderMain ordermainAssignCustomeer(@PathVariable Integer orderid, @PathVariable Integer customerid) {
			return orderMainService.ordermainAssignCustomer(orderid, customerid);
		}
		
	
}
