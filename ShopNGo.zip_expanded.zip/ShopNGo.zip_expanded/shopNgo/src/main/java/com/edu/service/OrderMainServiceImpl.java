package com.edu.service;

import java.util.Date;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.dao.Customer;
import com.edu.dao.OrderItem;
import com.edu.dao.OrderMain;
import com.edu.repository.CustomerRepository;
import com.edu.repository.OrderMainRepository;

@Service
public class OrderMainServiceImpl implements OrderMainService {

	@Autowired
	private OrderMainRepository orderMainRepository;
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public OrderMain createOrder(OrderMain order) {
		// TODO Auto-generated method stub
		return orderMainRepository.save(order);
	}

	@Override
	public OrderMain getOrderById(Integer orderid) {
	//TODO Auto-generated method stub
	return orderMainRepository.findById(orderid).orElse(null);
	}

	@Override
	public List<OrderMain> getAllOrders() {
		// TODO Auto-generated method stub
		return orderMainRepository.findAll();
	}

	@Override
	public OrderMain ordermainAssignCustomer(Integer orderid, Integer customerid) {
		// TODO Auto-generated method stub
		OrderMain eob=orderMainRepository.findById(orderid).get();
		Customer cob=customerRepository.findById(customerid).get();
		 eob.ordermainAssignCustomer(cob);
		 return orderMainRepository.save(eob);
	}





	
}
