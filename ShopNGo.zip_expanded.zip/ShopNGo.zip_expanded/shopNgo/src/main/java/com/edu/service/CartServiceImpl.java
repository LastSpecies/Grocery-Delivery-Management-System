package com.edu.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.dao.Cart;
import com.edu.dao.Customer;
import com.edu.dao.OrderItem;
import com.edu.dao.OrderMain;

import com.edu.error.GlobalException;
import com.edu.repository.CartRepository;
import com.edu.repository.CustomerRepository;
import com.edu.repository.OrderItemRepository;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private OrderItemRepository orderItemRepository;
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Cart createCart(Cart cart) {
		// TODO Auto-generated method stub
		return cartRepository.save(cart);
	}

	@Override
	public Cart cartAssignCustomer(Integer cartid, Integer customerid) {
		// TODO Auto-generated method stub
		Cart eob=cartRepository.findById(cartid).get();
		Customer cus=customerRepository.findById(customerid).get();
		 eob.cartAssignCustomer(cus);
		 return cartRepository.save(eob);
	}


	
	

}
