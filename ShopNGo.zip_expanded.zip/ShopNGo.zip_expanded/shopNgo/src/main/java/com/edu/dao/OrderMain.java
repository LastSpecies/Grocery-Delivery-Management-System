package com.edu.dao;

import java.util.Date;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity

public class OrderMain {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer orderid;

    @Temporal(TemporalType.TIMESTAMP)
    @NotNull(message = "Order date is required")
    @FutureOrPresent(message = "Order date must be a future or present date")
    private Date orderDate;

    @NotBlank(message = "Delivery address is required")
    @Size(max = 100, message = "Delivery address must be less than or equal to 100 characters")
    private String orderdeliveryAddress;
    
    @NotBlank(message = "Payment method is required")
    @Pattern(regexp = "^(Cash|Credit Card|PayPal)$", message = "Invalid payment method")
    private String orderpaymentMethod;
    
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id")
    private Customer customer;
    
    @OneToMany(mappedBy = "orderMain",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
   //@JoinColumn(name ="itemid")
    @JsonIgnore
    private List<OrderItem> orderItems;

	public OrderMain() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderMain(Integer orderid, Date orderDate, String orderdeliveryAddress, String orderpaymentMethod) {
		super();
		this.orderid = orderid;
		this.orderDate = orderDate;
		this.orderdeliveryAddress = orderdeliveryAddress;
		this.orderpaymentMethod = orderpaymentMethod;
	}

	public Integer getOrderid() {
		return orderid;
	}

	public void setOrderid(Integer orderid) {
		this.orderid = orderid;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderdeliveryAddress() {
		return orderdeliveryAddress;
	}

	public void setOrderdeliveryAddress(String orderdeliveryAddress) {
		this.orderdeliveryAddress = orderdeliveryAddress;
	}

	public String getOrderpaymentMethod() {
		return orderpaymentMethod;
	}

	public void setOrderpaymentMethod(String orderpaymentMethod) {
		this.orderpaymentMethod = orderpaymentMethod;
	}

	public List<OrderItem> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}

	@Override
	public String toString() {
		return "OrderMain [orderid=" + orderid + ", orderDate=" + orderDate + ", orderdeliveryAddress="
				+ orderdeliveryAddress + ", orderpaymentMethod=" + orderpaymentMethod + "]";
	}

	public void ordermainAssignCustomer(Customer cob) {
		// TODO Auto-generated method stub
	this.customer = cob;	
	}




   
  
}
