package com.edu.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.edu.dao.OrderItem;
import com.edu.dao.OrderMain;
import com.edu.dao.ShopkeeperProduct;
import com.edu.repository.OrderItemRepository;
import com.edu.repository.OrderMainRepository;

import com.edu.repository.ShopkeeperProductRepository;

@Service
public class OrderItemServiceImpl implements OrderItemService {
	
	@Autowired
	private OrderItemRepository orderItemRepository;
	@Autowired
	private OrderMainRepository  orderMainRepository;
	
	@Autowired
	private ShopkeeperProductRepository shopkeeperproductRepository;

	 @Override
	    public OrderItem createOrderItem(OrderItem orderItem) {
	        return orderItemRepository.save(orderItem);
	    }
	@Override
	public OrderItem orderitemAssignOrderMain(Integer itemid, Integer orderid) {
		OrderItem eob=orderItemRepository.findById(itemid).get();
		OrderMain dob=orderMainRepository.findById(orderid).get();
		 eob.orderitemAssignOrderMain(dob);
		 return orderItemRepository.save(eob);
	}
	@Override
	public OrderItem orderitemAssignProduct(Integer itemid, Integer shopkeeperproductid) {
		// TODO Auto-generated method stub
		OrderItem eob=orderItemRepository.findById(itemid).get();
		ShopkeeperProduct pob=shopkeeperproductRepository.findById(shopkeeperproductid).get();
		 eob.orderitemAssignProduct(pob);
		 return orderItemRepository.save(eob);
	}

}
