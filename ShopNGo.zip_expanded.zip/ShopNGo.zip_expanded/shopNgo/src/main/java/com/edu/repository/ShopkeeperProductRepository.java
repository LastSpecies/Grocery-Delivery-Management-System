package com.edu.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.edu.dao.ShopkeeperProduct;


@Repository
public interface ShopkeeperProductRepository extends JpaRepository<ShopkeeperProduct, Integer> {

	
	@Transactional

	@Modifying
	
	@Query(value = "update shopkeeper_product set shopkeeperproductquantity =:shopkeeperproductquantity,shopkeeperproductprice =:shopkeeperproductprice where shopkeeperproductname =:shopkeeperproductname", nativeQuery = true)
	public void updateProductByName(String shopkeeperproductname, Long shopkeeperproductquantity,
			Integer shopkeeperproductprice);

	
	
	@Transactional
	@Modifying
	@Query(value = "delete from shopkeeper_product p where p.shopkeeperproductname =:shopkeeperproductname",nativeQuery = true)
	public void deleteProductByName(String shopkeeperproductname);

}
