package com.edu.dao;
	
	import javax.persistence.*;
import javax.validation.constraints.Max;

import java.util.ArrayList;
	import java.util.List;

	@Entity
	public class Cart {
	 @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Integer cartid;

	 @Column(name = "quantity",nullable = false)
	 @Max(value = 999, message = "Cart quantity cannot exceed 10")
	    private Integer cartquantity;
	 
	 
	    @OneToOne
	    @JoinColumn(name = "customerid")
	    private Customer customer;


		public Cart() {
			super();
			// TODO Auto-generated constructor stub
		}


		public Cart(Integer cartid, Integer cartquantity) {
			super();
			this.cartid = cartid;
			this.cartquantity = cartquantity;
		}


		public Integer getCartid() {
			return cartid;
		}


		public void setCartid(Integer cartid) {
			this.cartid = cartid;
		}


		public Integer getCartquantity() {
			return cartquantity;
		}


		public void setCartquantity(Integer cartquantity) {
			this.cartquantity = cartquantity;
		}


		public Customer getCustomer() {
			return customer;
		}


		public void setCustomer(Customer customer) {
			this.customer = customer;
		}


		@Override
		public String toString() {
			return "Cart [cartid=" + cartid + ", cartquantity=" + cartquantity + "]";
		}


		public void cartAssignCustomer(Customer cus) {
			// TODO Auto-generated method stub
			this.customer = cus;
		}
	    
	    

	  

	

		
}
