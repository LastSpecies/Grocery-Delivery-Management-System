package com.edu.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.dao.Cart;
import com.edu.dao.OrderItem;
import com.edu.dao.OrderMain;
import com.edu.error.GlobalException;
import com.edu.repository.OrderMainRepository;
import com.edu.service.CartService;
import com.edu.service.OrderItemService;

@RestController
public class OrderItemController {
	
	@Autowired
	private  OrderItemService orderItemService;
	
	@Autowired
	private OrderMainRepository orderMainRepository;
	@Autowired
	private CartService cartService;

	
	
	// @PostMapping("/Orderitem")
	  //  public ResponseEntity<OrderItem> createOrderItem(@RequestBody OrderItem orderItem) {
	  //      OrderItem createdOrderItem = orderItemService.createOrderItem(orderItem);
	  //      return new ResponseEntity<>(createdOrderItem, HttpStatus.CREATED);
	//    }
	 
	
	@PostMapping("/createItem")
    public ResponseEntity<OrderItem> createOrderItem(@RequestBody OrderItem orderItem) {
        OrderItem createdOrderItem = orderItemService.createOrderItem(orderItem);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdOrderItem);
    }
	@PutMapping("/ItemassigndOrder/{itemid}/OrderMain/{orderid}")
	public OrderItem orderitemAssignOrderMain(@PathVariable Integer itemid, @PathVariable Integer orderid) {
		return orderItemService.orderitemAssignOrderMain(itemid, orderid);
	}
	
	@PutMapping("/ItemassigndProduct/{itemid}/ShopkeeperProduct/{shopkeeperproductid}")
	public OrderItem orderitemAssignProduct(@PathVariable Integer itemid, @PathVariable Integer shopkeeperproductid) {
		return orderItemService.orderitemAssignProduct(itemid, shopkeeperproductid);
	}
	
	
}
