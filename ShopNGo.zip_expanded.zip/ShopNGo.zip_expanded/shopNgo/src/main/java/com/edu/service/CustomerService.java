package com.edu.service;

import java.sql.Date;
import java.util.List;

import javax.validation.Valid;

import com.edu.dao.Customer;
import com.edu.error.GlobalException;

public interface CustomerService {

	public Customer registerCustomer(@Valid Customer customer) throws GlobalException;

	public boolean loginCustomer(String customerphoneno, String customerpassword);

	public List<Customer> getAllCustomer();
	
	public Customer getCustomerByPhoneno(String cname);

	public void deleteCustomerByCustomerPhoneno(String cpno);

	public String updateCustomerByCustomerPhoneno(String cpno, String customerfirstname);

	public void updateCustomerLastname(String cpno, String customerlastname);

	public void updateCustomerPassword(String cpno, String customerpassword);

	public void updateCustomerEmailid(@Valid String cpno, String customeremailid) throws GlobalException;

	public void updateCustomerdob(@Valid String cpno, Date customerdob);

	public Customer updateCustomerByCustomerid(@Valid Integer customerid, Customer customer) throws GlobalException;

	public List<Customer> deleteByCustomerid(Integer customerid);

	


}
