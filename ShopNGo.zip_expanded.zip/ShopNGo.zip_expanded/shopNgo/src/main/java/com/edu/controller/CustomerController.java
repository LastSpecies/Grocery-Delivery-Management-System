package com.edu.controller;

import java.sql.Date;
import java.util.List;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.edu.dao.Customer;
import com.edu.error.GlobalException;
import com.edu.repository.CustomerRepository;
import com.edu.service.CustomerService;

@RestController
@RequestMapping("/api/customers")
@CrossOrigin(origins="http://localhost:4200")
public class CustomerController {
	@Autowired
	private CustomerService customerservice;
	
	@PostMapping("/registerCustomer")
	ResponseEntity<Customer> saveAdmin(@Valid @RequestBody Customer customer) throws GlobalException {
	Customer obj= customerservice.registerCustomer(customer);
	return new ResponseEntity<Customer>(obj,HttpStatus.CREATED);

}
	
	@GetMapping("/loginCustomer/customerphoneno/{customerphoneno}/customerpassword/{customerpassword}")
	public boolean loginCustomer(@RequestBody Customer customer) {
		return customerservice.loginCustomer(customer.getCustomerphoneno(), customer.getCustomerpassword());
	}
	
	
	@GetMapping("/getAllCustomer")
	public List<Customer> getAllCustomer(){
		return customerservice.getAllCustomer();
		
	}
	
	@GetMapping("/getCustomerByCustomerByPhoneno/{cpno}")
	public Customer getCustomerByCustomerPhoneno(@PathVariable("cpno") String cpno) {
		return customerservice.getCustomerByPhoneno(cpno);
		
	}
	
	@DeleteMapping("/deleteCustomerByCustomerPhoneno/{cpno}")
	public String deleteCustomerByCustomerPhoneno(@PathVariable("cpno") String cpno) {
		customerservice.deleteCustomerByCustomerPhoneno(cpno);
		return "Customer is successfully deleted";
		
	}
	
	
	@PutMapping("/updateCustomerByCustomerPhoneno/{cpno}/cfname/{customerfirstname}")
	public String updateCustomerByCustomerPhoneno(@PathVariable("cpno") String cpno ,@PathVariable String customerfirstname) {
		customerservice.updateCustomerByCustomerPhoneno(cpno,customerfirstname);
	
		return "Customer first name is updated";
		
	}
	@PutMapping("/updateCustomerLastname/{cpno}/clname/{customerlastname}")
	public String updateCustomerLastname(@PathVariable("cpno") String cpno ,@PathVariable String customerlastname) {
		customerservice.updateCustomerLastname(cpno,customerlastname);
		return "Customer last name is updated";
		
	}
	
	@PutMapping("/updateCustomerPassword/{cpno}/cpass/{customerpassword}")
	public String updateCustomerPassword(@PathVariable("cpno") String cpno ,@PathVariable String customerpassword) {
		customerservice.updateCustomerPassword(cpno,customerpassword);
		return "Customer password is updated";
		
	}
	
	@PutMapping("/updateCustomerEmailid/{cpno}/cemail/{customeremailid}")
	public ResponseEntity<String> updateCustomerEmailid(@Valid @PathVariable("cpno") String cpno ,@PathVariable String customeremailid) throws GlobalException {
		customerservice.updateCustomerEmailid(cpno, customeremailid);
        return ResponseEntity.ok("Email ID updated successfully.");
		
	}
	
	@PutMapping("/updateCustomerdob/{cpno}/cdob/{customerdob}")
	public ResponseEntity<String> updateCustomerdob(@Valid @PathVariable("cpno") String cpno ,@PathVariable Date customerdob) throws GlobalException {
		customerservice.updateCustomerdob(cpno, customerdob);
        return ResponseEntity.ok("Customer date of birth updated successfully.");
		
	}
	
	@PutMapping("/updateCustomerById/{id}")
	public Customer updateCustomerByCustomerid(@Valid  @PathVariable("id") Integer customerid,@RequestBody Customer customer) throws GlobalException {
		return customerservice.updateCustomerByCustomerid(customerid,customer);
		
	}
	
	 @DeleteMapping("/deleteByCustomerid/{id}")
	    public List<Customer> deleteByCustomerid(@PathVariable("id") Integer customerid){
	    	return customerservice.deleteByCustomerid(customerid);
	    }
	
	
	
}	


