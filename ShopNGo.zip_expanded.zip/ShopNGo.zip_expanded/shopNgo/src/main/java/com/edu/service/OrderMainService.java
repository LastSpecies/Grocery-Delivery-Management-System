package com.edu.service;

import java.util.Date;
import java.util.List;

import com.edu.dao.OrderItem;
import com.edu.dao.OrderMain;

public interface OrderMainService {

	OrderMain createOrder(OrderMain order);

	OrderMain getOrderById(Integer orderid);

	List<OrderMain> getAllOrders();

	OrderMain ordermainAssignCustomer(Integer orderid, Integer customerid);

	


	

}
