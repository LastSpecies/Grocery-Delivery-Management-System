package com.edu.service;

import com.edu.dao.Cart;
import com.edu.dao.OrderItem;
import com.edu.error.GlobalException;

public interface CartService {

	Cart createCart(Cart cart);

	Cart cartAssignCustomer(Integer cartid, Integer customerid);



	
    
	

}
