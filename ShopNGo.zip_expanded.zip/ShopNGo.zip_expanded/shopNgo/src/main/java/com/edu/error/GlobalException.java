package com.edu.error;

public class GlobalException extends Exception{

	public GlobalException(String message) {
		super(message);
	
	}
	

}
