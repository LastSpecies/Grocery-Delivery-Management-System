package com.edu.dao;

import javax.persistence.CascadeType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
public class OrderItem {

	   @Id
	   @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Integer itemid;
	    
	    @ManyToOne(cascade = {CascadeType.PERSIST,CascadeType.MERGE},fetch = FetchType.LAZY)
	    @JoinColumn(name = "orderid")
	    @JsonIgnore
	    private OrderMain orderMain;
	    
	  
	    
	    @ManyToOne
	    @JoinColumn(name = "shopkeeperproductid")
	    @JsonIgnore
	    private ShopkeeperProduct shopkeeperproduct;
	    
	    @Column(nullable = false)
	    private int itemquantity;

	
		public OrderItem() {
			super();
			// TODO Auto-generated constructor stub
		}
		public OrderItem(Integer itemid, int itemquantity) {
			super();
			this.itemid = itemid;
			this.itemquantity = itemquantity;
		}
		public Integer getItemid() {
			return itemid;
		}
		public void setItemid(Integer itemid) {
			this.itemid = itemid;
		}
		public OrderMain getOrderMain() {
			return orderMain;
		}
		public void setOrderMain(OrderMain orderMain) {
			this.orderMain = orderMain;
		}
		public ShopkeeperProduct getProduct() {
			return shopkeeperproduct;
		}
		public void setProduct(ShopkeeperProduct shopkeeperproduct) {
			this.shopkeeperproduct = shopkeeperproduct;
		}
		public int getItemquantity() {
			return itemquantity;
		}
		public void setItemquantity(int itemquantity) {
			this.itemquantity = itemquantity;
		}
		@Override
		public String toString() {
			return "OrderItem [itemid=" + itemid + ", itemquantity=" + itemquantity + "]";
		}
		public void orderitemAssignOrderMain(OrderMain dob) {
			// TODO Auto-generated method stub
			this.orderMain = dob;
		}
		public void orderitemAssignProduct(ShopkeeperProduct pob) {
			// TODO Auto-generated method stub
			this.shopkeeperproduct = pob;
		}
		
		
		
}
